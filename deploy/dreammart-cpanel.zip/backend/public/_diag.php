<?php
/**
 * ============================================================
 *  Dream Mart — Installation self-check
 * ------------------------------------------------------------
 *  ব্রাউজারে খুলুন:  http://your-domain/backend/_diag.php
 *
 *  Laravel বুট না করেই সব শর্ত পরীক্ষা করে, তাই সাইট 500 দিলেও
 *  এই পেজটা কাজ করবে আর আসল কারণটা দেখিয়ে দেবে।
 *
 *  সব সবুজ দেখার পর এই ফাইলটা ডিলিট করে দিন।
 * ============================================================
 */

declare(strict_types=1);

$root = dirname(__DIR__);            // .../public_html/backend
$rows = [];
$fail = 0;
$warn = 0;

function row(string $label, bool $ok, string $detail = '', bool $isWarning = false): void
{
    global $rows, $fail, $warn;
    $rows[] = ['label' => $label, 'ok' => $ok, 'detail' => $detail, 'warn' => $isWarning];
    if (! $ok) {
        $isWarning ? $warn++ : $fail++;
    }
}

// ---------- ১. PHP ----------
$phpOk = PHP_VERSION_ID >= 80200;
row('PHP version', $phpOk, PHP_VERSION . ($phpOk ? '' : ' — Laravel 12-এর জন্য ৮.২ বা তার উপরে দরকার। cPanel → MultiPHP Manager থেকে বদলান।'));

$needed = ['pdo_mysql', 'mbstring', 'openssl', 'tokenizer', 'ctype', 'json', 'bcmath', 'fileinfo', 'curl', 'xml'];
$missing = array_values(array_filter($needed, fn ($e) => ! extension_loaded($e)));
row('PHP extensions', $missing === [], $missing === [] ? implode(', ', $needed) : 'অনুপস্থিত: ' . implode(', ', $missing) . ' — cPanel → Select PHP Version → Extensions থেকে টিক দিন।');

// ---------- ২. ফাইল ----------
row('vendor/autoload.php', is_file("$root/vendor/autoload.php"), is_file("$root/vendor/autoload.php") ? 'আছে' : 'নেই — zip ঠিকমতো extract হয়নি।');
row('bootstrap/cache/packages.php', is_file("$root/bootstrap/cache/packages.php"), is_file("$root/bootstrap/cache/packages.php") ? 'আছে' : 'নেই — Laravel প্রতি রিকোয়েস্টে নতুন করে বানানোর চেষ্টা করবে।');
row('.env', is_file("$root/.env"), is_file("$root/.env") ? 'আছে' : 'নেই — File Manager-এ Show Hidden Files চালু করে দেখুন, dotfile আপলোড হয়েছে কিনা।');

// ---------- ৩. লেখার অনুমতি ----------
$writable = [
    'storage/logs',
    'storage/framework/cache/data',
    'storage/framework/sessions',
    'storage/framework/views',
    'bootstrap/cache',
    'public/storage',
];
foreach ($writable as $rel) {
    $path = "$root/$rel";
    if (! is_dir($path)) {
        row("$rel (folder)", false, 'ফোল্ডারটাই নেই — নিচের "Fix folders" বোতামে চাপ দিন।');
        continue;
    }
    $ok = is_writable($path);
    row("$rel", $ok, $ok ? 'writable (' . substr(sprintf('%o', fileperms($path)), -3) . ')' : 'লেখা যাচ্ছে না — permission 755, না হলে 775 দিন।');
}

// ---------- ৪. ডাটাবেস ----------
$env = [];
if (is_file("$root/.env")) {
    foreach (file("$root/.env", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if ($line === '' || $line[0] === '#' || ! str_contains($line, '=')) {
            continue;
        }
        [$k, $v] = explode('=', $line, 2);
        $env[trim($k)] = trim(trim($v), "\"'");
    }
}

$dbName = $env['DB_DATABASE'] ?? '';
$dbUser = $env['DB_USERNAME'] ?? '';
$dbHost = $env['DB_HOST'] ?? '127.0.0.1';
$dbPort = $env['DB_PORT'] ?? '3306';

row('APP_KEY সেট আছে', ! empty($env['APP_KEY']), ! empty($env['APP_KEY']) ? 'হ্যাঁ' : 'নেই — .env এ APP_KEY লাইনটা দরকার।');

$pdo = null;
try {
    $pdo = new PDO("mysql:host=$dbHost;port=$dbPort;dbname=$dbName;charset=utf8mb4", $dbUser, $env['DB_PASSWORD'] ?? '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_TIMEOUT => 5,
    ]);
    row('ডাটাবেস কানেকশন', true, "$dbUser@$dbHost → $dbName");
} catch (Throwable $e) {
    row('ডাটাবেস কানেকশন', false, htmlspecialchars($e->getMessage()) . ' — cPanel → MySQL Databases এ ইউজারটা ডাটাবেসের সাথে "ALL PRIVILEGES" সহ যোগ করা আছে কিনা দেখুন।');
}

if ($pdo) {
    $tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
    $count  = count($tables);
    row('টেবিল ইমপোর্ট হয়েছে', $count >= 44, $count >= 44
        ? "$count টা টেবিল"
        : "মাত্র $count টা টেবিল পাওয়া গেল, ৪৪টা থাকার কথা — phpMyAdmin এ digita42_dreammart.sql ফাইলটা Import করুন।");

    $must = ['products', 'categories', 'orders', 'users', 'site_settings', 'blocked_customers'];
    $lost = array_values(array_diff($must, $tables));
    row('জরুরি টেবিলগুলো', $lost === [], $lost === [] ? implode(', ', $must) : 'নেই: ' . implode(', ', $lost));

    if (in_array('products', $tables, true)) {
        $n = (int) $pdo->query('SELECT COUNT(*) FROM products')->fetchColumn();
        row('প্রোডাক্ট ডাটা', $n > 0, "$n টা প্রোডাক্ট");
    }
    if (in_array('users', $tables, true)) {
        $n = (int) $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
        row('অ্যাডমিন ইউজার', $n > 0, "$n টা ইউজার" . ($n ? '' : ' — লগইন করা যাবে না।'));
    }
    // বাংলা ঠিকমতো ইমপোর্ট হয়েছে কিনা
    if (in_array('categories', $tables, true)) {
        $sample = (string) $pdo->query('SELECT name FROM categories LIMIT 1')->fetchColumn();
        $okBn   = $sample !== '' && ! str_contains($sample, '??');
        row('বাংলা লেখা (encoding)', $okBn, $okBn ? htmlspecialchars($sample) : 'ভাঙা দেখাচ্ছে: ' . htmlspecialchars($sample) . ' — ইমপোর্টের সময় utf8mb4 সিলেক্ট করে আবার করুন।', true);
    }
}

// ---------- ৫. আপলোড করা ছবি ----------
$imgDir = "$root/public/storage/uploads";
$imgN   = is_dir($imgDir) ? count(glob("$imgDir/*/*") ?: []) : 0;
row('আপলোড করা ছবি', $imgN > 0, $imgN > 0 ? "$imgN টা ফাইল" : 'public/storage/uploads খালি — zip পুরোপুরি extract হয়নি।', true);

// ---------- ৬. rewrite ----------
$rw = function_exists('apache_get_modules') ? in_array('mod_rewrite', apache_get_modules(), true) : null;
row('mod_rewrite', $rw !== false, $rw === null ? 'LiteSpeed/CGI — সরাসরি দেখা যায় না, /backend/api/health খুলে যাচাই করুন' : ($rw ? 'চালু' : 'বন্ধ'), true);

// ---------- Fix action ----------
$fixed = [];
if (($_GET['fix'] ?? '') === '1') {
    $dirs = [
        'storage', 'storage/app', 'storage/app/private', 'storage/app/public',
        'storage/framework', 'storage/framework/cache', 'storage/framework/cache/data',
        'storage/framework/sessions', 'storage/framework/views', 'storage/logs',
        'bootstrap/cache', 'public/storage',
    ];
    foreach ($dirs as $d) {
        $p = "$root/$d";
        if (! is_dir($p)) {
            @mkdir($p, 0755, true);
            $fixed[] = "তৈরি হলো: $d";
        }
        if (is_dir($p) && ! is_writable($p)) {
            @chmod($p, 0775);
            $fixed[] = "permission বদলানো হলো: $d";
        }
    }
    if ($fixed === []) {
        $fixed[] = 'সব ফোল্ডার আগে থেকেই ঠিক ছিল — কিছু বদলাতে হয়নি।';
    }
}

$status = $fail > 0 ? 'fail' : ($warn > 0 ? 'warn' : 'pass');
?>
<!doctype html>
<html lang="bn">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>Dream Mart — Install check</title>
<style>
  :root { color-scheme: light dark; }
  body { font: 15px/1.6 system-ui, "Segoe UI", Roboto, sans-serif; margin: 0; padding: 24px 16px;
         background: #f6f7f9; color: #16181d; }
  .wrap { max-width: 760px; margin: 0 auto; }
  h1 { font-size: 20px; margin: 0 0 4px; }
  .sub { color: #5c6270; margin: 0 0 20px; font-size: 13px; }
  .banner { padding: 14px 16px; border-radius: 10px; font-weight: 600; margin-bottom: 20px; }
  .pass { background: #e6f7ec; color: #0f6b34; border: 1px solid #b7e4c7; }
  .warn { background: #fff6e5; color: #8a5a00; border: 1px solid #ffe0a3; }
  .fail { background: #fdeaea; color: #99201a; border: 1px solid #f7c3c0; }
  table { width: 100%; border-collapse: collapse; background: #fff; border-radius: 10px;
          overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,.08); }
  td { padding: 10px 14px; border-bottom: 1px solid #eceef1; vertical-align: top; }
  tr:last-child td { border-bottom: 0; }
  td.i { width: 28px; font-size: 16px; }
  td.l { width: 220px; font-weight: 600; }
  td.d { color: #5c6270; font-size: 13px; word-break: break-word; }
  .btn { display: inline-block; margin: 18px 8px 0 0; padding: 9px 16px; border-radius: 8px;
         background: #16181d; color: #fff; text-decoration: none; font-size: 14px; }
  .btn.alt { background: #fff; color: #16181d; border: 1px solid #d3d7de; }
  .note { margin-top: 22px; padding: 14px 16px; background: #fff; border-radius: 10px;
          border: 1px solid #eceef1; font-size: 13px; color: #5c6270; }
  code { background: #eceef1; padding: 1px 5px; border-radius: 4px; font-size: 12px; }
  @media (prefers-color-scheme: dark) {
    body { background: #14161a; color: #e6e8ec; }
    table, .note { background: #1c1f25; box-shadow: none; border-color: #2a2e36; }
    td { border-color: #2a2e36; } td.d, .sub, .note { color: #9aa1ad; }
    code { background: #2a2e36; } .btn.alt { background: #1c1f25; color: #e6e8ec; border-color: #3a3f49; }
    .pass { background: #12301f; color: #7ee2a8; border-color: #1d4a31; }
    .warn { background: #33280d; color: #ffcf70; border-color: #4d3d13; }
    .fail { background: #351816; color: #ff9d95; border-color: #4e2320; }
  }
</style>
</head>
<body>
<div class="wrap">
  <h1>Dream Mart — ইনস্টল চেক</h1>
  <p class="sub"><?= htmlspecialchars($_SERVER['HTTP_HOST'] ?? '') ?> · <?= date('d M Y, H:i') ?></p>

  <?php if ($status === 'pass'): ?>
    <div class="banner pass">✓ সব ঠিক আছে। সাইট চালু হওয়ার কথা — এখন এই <code>_diag.php</code> ফাইলটা ডিলিট করে দিন।</div>
  <?php elseif ($status === 'warn'): ?>
    <div class="banner warn">⚠ <?= $warn ?> টা ছোট সতর্কতা আছে, কিন্তু সাইট চলার কথা।</div>
  <?php else: ?>
    <div class="banner fail">✕ <?= $fail ?> টা সমস্যা আছে — নিচে লাল দাগানো লাইনগুলো ঠিক করুন।</div>
  <?php endif; ?>

  <?php if ($fixed): ?>
    <div class="banner warn"><?= implode('<br>', array_map('htmlspecialchars', $fixed)) ?></div>
  <?php endif; ?>

  <table>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td class="i"><?= $r['ok'] ? '✅' : ($r['warn'] ? '⚠️' : '❌') ?></td>
        <td class="l"><?= htmlspecialchars($r['label']) ?></td>
        <td class="d"><?= $r['detail'] ?></td>
      </tr>
    <?php endforeach; ?>
  </table>

  <a class="btn" href="?fix=1">Fix folders</a>
  <a class="btn alt" href="?">আবার চেক করুন</a>
  <a class="btn alt" href="api/health">API health দেখুন</a>

  <div class="note">
    <strong>এই ফাইলটা কী করে?</strong> Laravel চালু না করেই সার্ভারের অবস্থা দেখে —
    তাই সাইট 500 error দিলেও এটা কাজ করে। <em>Fix folders</em> বোতামটা কেবল অনুপস্থিত
    ফোল্ডার বানায় আর permission ঠিক করে, ডাটাবেসে হাত দেয় না।<br><br>
    সব সবুজ হয়ে গেলে <code>backend/public/_diag.php</code> ফাইলটা <strong>মুছে ফেলুন</strong>।
  </div>
</div>
</body>
</html>
